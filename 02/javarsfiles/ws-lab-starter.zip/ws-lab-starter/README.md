# Web Services for Java EE — Lab Starter Project

**Platform:** Java 11 LTS · Tomcat 9.0 · JAX-WS 2.3 (jakarta namespace) · JAX-RS 2.1 · Maven 3.8+

---

## Quick Start

```bash
# 1. Verify environment
java -version      # must be 11.x
mvn  -version      # must be 3.8+

# 2. Build
mvn clean package -DskipTests

# 3. Run baseline tests — all 4 must PASS before starting
mvn test -Dtest=SmokeTest

# 4. Deploy to Tomcat 9 (needed for Lab 9 JAX-RS + JAX-WS in one WAR)
cp target/ws-lab.war $CATALINA_HOME/webapps/
$CATALINA_HOME/bin/startup.sh
curl http://localhost:8080/ws-lab/api/health

# 5. Run standalone endpoint (Labs 2, 3, 6, 7)
mvn exec:java -Dexec.mainClass=com.example.ws.hello.HelloEndpoint
```

---

## Project Structure

```
ws-lab-starter/
├── pom.xml
└── src/
    ├── main/
    │   ├── java/com/example/
    │   │   ├── api/
    │   │   │   ├── WsLabApplication.java       ✅ JAX-RS @ApplicationPath("/api")
    │   │   │   └── HealthResource.java         ✅ GET /api/health
    │   │   └── ws/
    │   │       ├── hello/
    │   │       │   ├── HelloService.java        ✅ SEI (interface)
    │   │       │   ├── HelloServiceImpl.java    🔧 Lab 2 — implement sayHello() + getTime()
    │   │       │   └── HelloEndpoint.java       🔧 Lab 2 — add Endpoint.publish()
    │   │       ├── order/
    │   │       │   ├── OrderRequest.java        ✅ JAXB bean (annotated)
    │   │       │   ├── OrderResponse.java       ✅ JAXB bean (annotated)
    │   │       │   ├── OrderService.java        ✅ SEI
    │   │       │   └── OrderServiceImpl.java    🔧 Lab 3 — implement placeOrder()
    │   │       ├── inventory/
    │   │       │   ├── InventoryServiceImpl.java 🔧 Lab 6 — implement getStock() + reserveStock()
    │   │       │   └── InventoryEndpoint.java    🔧 Lab 6 — add Endpoint.publish()
    │   │       └── echo/
    │   │           ├── EchoProvider.java        🔧 Lab 7 — implement invoke()
    │   │           ├── EchoEndpoint.java        ✅ Publishes EchoProvider
    │   │           └── SaajHelper.java          ✅ bodyToBytes() helper for Lab 8
    │   └── resources/
    │       └── wsdl/
    │           ├── hello.wsdl    ✅ Lab 1 WSDL reading exercise
    │           └── weather.wsdl ✅ Lab 5 wsimport source
    └── test/java/com/example/
        └── SmokeTest.java        ✅ 4 baseline tests — do not modify
```

---

## Lab Roadmap

| Lab | Endpoint | Port | Main Class / Plugin |
|-----|----------|------|---------------------|
| **Lab 1** | Analysis only | — | Read `hello.wsdl` |
| **Lab 2** | HelloService | 9090 | `HelloEndpoint` |
| **Lab 3** | OrderService | 9091 | `OrderServiceImpl.main()` |
| **Lab 4** | ProductService | 9092 | Create new class |
| **Lab 5** | WeatherService | 9093 | `jaxws-maven-plugin` (uncomment in pom.xml) |
| **Lab 6** | InventoryService | 9092 | `InventoryEndpoint` |
| **Lab 7** | EchoService | 9090 | `EchoEndpoint` |
| **Lab 8** | OrderService | 9091 | SAAJ standalone |
| **Lab 9** | WAR (all) | 8080 | Tomcat deployment |

---

## Key JAX-WS Rules (Java 11)

JAX-WS was removed from the JDK in Java 9. This project includes:
- `com.sun.xml.ws:jaxws-rt` — JAX-WS runtime
- `jakarta.xml.ws:jakarta.xml.ws-api` — API (jakarta namespace)
- `jakarta.xml.bind:jakarta.xml.bind-api` — JAXB API
- `com.sun.xml.bind:jaxb-impl` — JAXB runtime

**Always import from `jakarta.jws.*` and `jakarta.xml.ws.*`** — NOT `javax.jws.*` or `javax.xml.ws.*`.

---

## Lab 5 — Enabling wsimport

1. Uncomment the `jaxws-maven-plugin` block in `pom.xml`
2. Run: `mvn generate-sources`
3. Generated classes appear in: `target/generated-sources/wsimport/`
4. Mark `target/generated-sources/wsimport/` as a Generated Sources Root in your IDE

---

## Lab 6 — Running wsgen

After implementing `InventoryServiceImpl`:

```bash
mvn compile
wsgen -cp target/classes \
      -wsdl \
      -d target/generated-sources/wsgen \
      -s target/generated-sources/wsgen \
      com.example.ws.inventory.InventoryServiceImpl
```

---

## Common Problems

**`ClassNotFoundException: jakarta.jws.WebService`**
JAX-WS jars not on classpath. Check pom.xml includes `jaxws-rt`.

**`UnsupportedOperationException: TODO`**
Method not yet implemented — check the lab task number in the Javadoc comment.

**Port already in use**
Another endpoint is running on the same port. Stop it (press ENTER in its terminal) or use a different port number.

**WSDL returns empty / 404**
The endpoint is not running. Start it with `mvn exec:java -Dexec.mainClass=...`.

**wsimport fails: "No WSDL found"**
Check the `<wsdlDirectory>` and `<wsdlFiles>` in pom.xml match the actual file location.
