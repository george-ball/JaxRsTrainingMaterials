package com.example.ws.echo;

import jakarta.xml.ws.Endpoint;

/**
 * Standalone publisher for EchoProvider.
 * LAB 7 — Task 7.2: after implementing EchoProvider, run this and
 * write the Dispatch<Source> client.
 *
 * Run with:
 *   mvn exec:java -Dexec.mainClass=com.example.ws.echo.EchoEndpoint
 */
public class EchoEndpoint {

    public static void main(String[] args) throws Exception {
        String address = "http://localhost:9090/echo";
        Endpoint ep = Endpoint.publish(address, new EchoProvider());
        System.out.println("EchoProvider at: " + address);
        System.out.println("Press ENTER to stop...");
        System.in.read();
        ep.stop();
    }
}
