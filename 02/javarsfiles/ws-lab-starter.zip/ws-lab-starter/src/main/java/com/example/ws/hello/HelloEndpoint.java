package com.example.ws.hello;

import jakarta.xml.ws.Endpoint;

/**
 * Standalone publisher for HelloService.
 * LAB 2 — Task 2.2: complete the Endpoint.publish() call.
 *
 * Run with:
 *   mvn exec:java -Dexec.mainClass=com.example.ws.hello.HelloEndpoint
 *
 * Then retrieve the WSDL:
 *   curl http://localhost:9090/hello?wsdl
 */
public class HelloEndpoint {

    public static void main(String[] args) throws Exception {
        String address = "http://localhost:9090/hello";

        // TODO:
        //   Endpoint ep = Endpoint.publish(address, new HelloServiceImpl());
        //   System.out.println("Published at: " + address);
        //   System.out.println("WSDL at:      " + address + "?wsdl");
        //   System.out.println("Press ENTER to stop...");
        //   System.in.read();
        //   ep.stop();

        System.out.println("TODO — implement Endpoint.publish() in Lab 2 Task 2.2");
    }
}
