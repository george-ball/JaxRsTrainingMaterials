package com.example.ws.order;

import jakarta.xml.bind.annotation.*;

/**
 * JAXB-annotated order response bean.
 * LAB 3 — complete and working, used as the return type of placeOrder().
 */
@XmlRootElement(name = "orderResponse", namespace = "http://example.com/order")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = { "orderId", "status", "message" })
public class OrderResponse {

    @XmlElement(required = true) private String orderId;
    @XmlElement(required = true) private String status;
    @XmlElement                  private String message;

    public OrderResponse() {}
    public String getOrderId()              { return orderId; }
    public void   setOrderId(String id)     { this.orderId = id; }
    public String getStatus()               { return status; }
    public void   setStatus(String s)       { this.status = s; }
    public String getMessage()              { return message; }
    public void   setMessage(String m)      { this.message = m; }
}
