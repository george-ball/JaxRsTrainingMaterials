package com.example.ws.inventory;

import jakarta.xml.ws.Endpoint;

/**
 * Standalone publisher for InventoryService.
 * LAB 6 — Task 6.1: complete the Endpoint.publish() call.
 *
 * Run with:
 *   mvn exec:java -Dexec.mainClass=com.example.ws.inventory.InventoryEndpoint
 *
 * Then retrieve the WSDL:
 *   curl http://localhost:9092/inventory?wsdl
 *
 * Run wsgen after compiling:
 *   mvn compile
 *   wsgen -cp target/classes -wsdl -d target/generated-sources/wsgen \
 *         -s target/generated-sources/wsgen \
 *         com.example.ws.inventory.InventoryServiceImpl
 */
public class InventoryEndpoint {

    public static void main(String[] args) throws Exception {
        String address = "http://localhost:9092/inventory";

        // TODO (Lab 6 Task 6.1):
        //   Endpoint ep = Endpoint.publish(address, new InventoryServiceImpl());
        //   System.out.println("InventoryService at: " + address + "?wsdl");
        //   System.out.println("Press ENTER to stop...");
        //   System.in.read();
        //   ep.stop();

        System.out.println("TODO — implement Endpoint.publish() in Lab 6 Task 6.1");
    }
}
