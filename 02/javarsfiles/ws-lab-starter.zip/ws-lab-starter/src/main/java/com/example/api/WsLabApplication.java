package com.example.api;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * JAX-RS Application — base URI: /api.  Used in Lab 9.
 *
 * @ApplicationPath("/api") registers all @Path resources under /api/*.
 * Import from javax.ws.rs (NOT jakarta.ws.rs) — correct for JAX-RS 2.1
 * on Tomcat 9 with Jersey 2.x.
 */
@ApplicationPath("/api")
public class WsLabApplication extends Application { }
