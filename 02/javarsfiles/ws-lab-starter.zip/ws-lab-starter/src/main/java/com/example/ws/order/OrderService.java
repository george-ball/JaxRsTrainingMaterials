package com.example.ws.order;

import jakarta.jws.*;
import jakarta.jws.soap.SOAPBinding;
import jakarta.xml.ws.Endpoint;

/**
 * OrderService SEI. Complete — do not modify.
 */
@WebService(targetNamespace = "http://example.com/order")
public interface OrderService {
    OrderResponse placeOrder(@WebParam(name = "request") OrderRequest request);
}
