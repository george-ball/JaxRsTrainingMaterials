package com.example.ws.hello;

import jakarta.jws.WebService;

/**
 * HelloService SEI (Service Endpoint Interface).
 * LAB 2 — Task 2.3: add @WebService annotation with correct targetNamespace.
 */
@WebService(targetNamespace = "http://example.com/hello")
public interface HelloService {
    String sayHello(String name);
    String getTime();
}
