package com.example.ws.echo;

import jakarta.xml.soap.*;
import java.io.ByteArrayOutputStream;

/**
 * Utility helpers for Labs 7 and 8.
 * Complete – do not modify.
 */
public class SaajHelper {

    /**
     * Converts the SOAPBody of a SOAPMessage to a byte array.
     * Used in Lab 8 Task 8.3 as input to the StAX XMLStreamReader.
     */
    public static byte[] bodyToBytes(SOAPMessage message) throws Exception {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        message.writeTo(baos);
        return baos.toByteArray();
    }

    /**
     * Prints a SOAPMessage to System.out for debugging.
     */
    public static void print(SOAPMessage message) throws Exception {
        System.out.println("=== SOAP Message ===");
        message.writeTo(System.out);
        System.out.println("\n===================");
    }
}
