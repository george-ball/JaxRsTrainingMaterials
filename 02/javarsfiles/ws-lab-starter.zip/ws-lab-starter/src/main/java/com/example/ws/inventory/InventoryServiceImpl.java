package com.example.ws.inventory;

import jakarta.jws.*;
import jakarta.jws.soap.SOAPBinding;
import jakarta.xml.ws.Endpoint;

/**
 * InventoryService implementation skeleton.
 * LAB 6 — Tasks 6.1 and 6.2: implement getStock() and reserveStock(),
 * then publish with Endpoint.publish() and generate artifacts with wsgen.
 */
@WebService(
    serviceName     = "InventoryService",
    portName        = "InventoryPort",
    targetNamespace = "http://example.com/inventory"
)
@SOAPBinding(style = SOAPBinding.Style.DOCUMENT, use = SOAPBinding.Use.LITERAL)
public class InventoryServiceImpl {

    @WebMethod
    public int getStock(@WebParam(name = "sku") String sku) {
        // TODO: return Math.abs(sku.hashCode() % 100) + 1
        throw new UnsupportedOperationException("TODO — Lab 6 Task 6.1");
    }

    @WebMethod
    public boolean reserveStock(
            @WebParam(name = "sku")      String sku,
            @WebParam(name = "quantity") int    quantity) {
        // TODO: return quantity > 0 && quantity <= getStock(sku)
        throw new UnsupportedOperationException("TODO — Lab 6 Task 6.1");
    }
}
