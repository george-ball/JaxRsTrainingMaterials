package com.example.ws.order;

import jakarta.jws.*;
import jakarta.jws.soap.SOAPBinding;
import jakarta.xml.ws.Endpoint;

/**
 * OrderService implementation skeleton.
 * LAB 3 — Task 3.2: implement placeOrder().
 */
@WebService(
    serviceName     = "OrderService",
    portName        = "OrderPort",
    targetNamespace = "http://example.com/order"
)
@SOAPBinding(style = SOAPBinding.Style.DOCUMENT, use = SOAPBinding.Use.LITERAL)
public class OrderServiceImpl implements OrderService {

    @WebMethod(operationName = "placeOrder")
    @Override
    public OrderResponse placeOrder(@WebParam(name = "request") OrderRequest request) {
        // TODO (Lab 3 Task 3.2):
        //   1. if request.getQuantity() <= 0:
        //        return rejected response
        //   2. Generate orderId = "ORD-" + System.currentTimeMillis()
        //   3. Return accepted OrderResponse
        throw new UnsupportedOperationException("TODO — Lab 3 Task 3.2");
    }

    // Standalone publisher for Lab 3 testing
    public static void main(String[] args) throws Exception {
        String address = "http://localhost:9091/order";
        Endpoint ep = Endpoint.publish(address, new OrderServiceImpl());
        System.out.println("OrderService at: " + address + "?wsdl");
        System.out.println("Press ENTER to stop...");
        System.in.read();
        ep.stop();
    }
}
