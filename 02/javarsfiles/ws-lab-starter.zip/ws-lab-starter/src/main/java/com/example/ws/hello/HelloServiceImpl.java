package com.example.ws.hello;

import jakarta.jws.*;
import jakarta.jws.soap.SOAPBinding;

/**
 * HelloService implementation.
 * LAB 2 — Tasks 2.1 and 2.2: implement sayHello() and getTime(), then publish.
 */
@WebService(
    serviceName     = "HelloService",
    portName        = "HelloPort",
    targetNamespace = "http://example.com/hello"
)
@SOAPBinding(style = SOAPBinding.Style.DOCUMENT, use = SOAPBinding.Use.LITERAL)
public class HelloServiceImpl implements HelloService {

    @WebMethod(operationName = "sayHello")
    @Override
    public String sayHello(@WebParam(name = "name") String name) {
        // TODO: return "Hello, " + name + "! From JAX-WS."
        throw new UnsupportedOperationException("TODO — Lab 2 Task 2.1");
    }

    @WebMethod(operationName = "getTime")
    @Override
    public String getTime() {
        // TODO: return java.time.LocalDateTime.now().toString()
        throw new UnsupportedOperationException("TODO — Lab 2 Task 2.1");
    }
}
