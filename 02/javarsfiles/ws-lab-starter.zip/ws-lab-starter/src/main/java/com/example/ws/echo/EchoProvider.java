package com.example.ws.echo;

import jakarta.xml.ws.*;
import jakarta.xml.soap.*;

/**
 * EchoProvider — a low-level Provider<SOAPMessage> implementation.
 * LAB 7 — Task 7.1: implement the invoke() method.
 *
 * This provider receives the full SOAPMessage without any JAXB data binding.
 * It is the server-side counterpart to Dispatch<SOAPMessage>.
 *
 * Publish with:
 *   mvn exec:java -Dexec.mainClass=com.example.ws.echo.EchoEndpoint
 */
@WebServiceProvider(
    serviceName     = "EchoService",
    portName        = "EchoPort",
    targetNamespace = "http://example.com/echo"
)
@ServiceMode(value = Service.Mode.MESSAGE)   // MESSAGE = full SOAPMessage (incl. headers)
public class EchoProvider implements Provider<SOAPMessage> {

    @Override
    public SOAPMessage invoke(SOAPMessage request) {
        try {
            // TODO (Lab 7 Task 7.1):
            //   1. Extract text from body: request.getSOAPBody().getFirstChild().getTextContent()
            //   2. Create response:
            //        MessageFactory mf = MessageFactory.newInstance();
            //        SOAPMessage response = mf.createMessage();
            //        response.getSOAPBody()
            //                .addChildElement("echoResponse")
            //                .setTextContent("ECHO: " + text);
            //        response.saveChanges();
            //   3. return response;
            throw new UnsupportedOperationException("TODO — Lab 7 Task 7.1");
        } catch (SOAPException e) {
            throw new WebServiceException("SOAP error in EchoProvider", e);
        }
    }
}
