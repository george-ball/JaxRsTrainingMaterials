package com.example.api;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.xml.bind.annotation.*;
import java.time.LocalDateTime;

/**
 * Health check endpoint — complete, used in Lab 9.
 *
 * GET /api/health  →  XML:
 * <?xml version="1.0" encoding="UTF-8"?>
 * <health>
 *   <status>UP</status>
 *   <service>WsLab</service>
 *   <timestamp>2024-06-15T10:30:00</timestamp>
 * </health>
 *
 * Note on namespaces:
 *   JAX-RS annotations  — javax.ws.rs.*     (correct for Tomcat 9 / JAX-RS 2.1)
 *   JAXB annotations    — javax.xml.bind.*  (correct for the response bean)
 *   JAX-WS annotations  — jakarta.xml.ws.*  (used in the ws.* packages — intentional)
 */
@Path("/health")
public class HealthResource {

    @XmlRootElement(name = "health")
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class HealthStatus {
        @XmlElement public String status;
        @XmlElement public String service;
        @XmlElement public String timestamp;
        public HealthStatus() {}
        public HealthStatus(String status, String service, String timestamp) {
            this.status = status; this.service = service; this.timestamp = timestamp;
        }
    }

    @GET
    @Produces(MediaType.APPLICATION_XML)
    public HealthStatus check() {
        return new HealthStatus("UP", "WsLab", LocalDateTime.now().toString());
    }
}
