package com.example.ws.order;

import jakarta.xml.bind.annotation.*;

/**
 * JAXB-annotated order request bean.
 * LAB 3 — Task 3.1: annotations are already provided; read them and
 * understand how they map to the WSDL schema elements.
 */
@XmlRootElement(name = "orderRequest", namespace = "http://example.com/order")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = { "customerId", "productId", "quantity" })
public class OrderRequest {

    @XmlElement(required = true) private String customerId;
    @XmlElement(required = true) private String productId;
    @XmlElement(required = true) private int    quantity;

    public OrderRequest() {}
    public OrderRequest(String customerId, String productId, int quantity) {
        this.customerId = customerId; this.productId = productId; this.quantity = quantity;
    }
    public String getCustomerId()               { return customerId; }
    public void   setCustomerId(String id)      { this.customerId = id; }
    public String getProductId()                { return productId; }
    public void   setProductId(String id)       { this.productId = id; }
    public int    getQuantity()                 { return quantity; }
    public void   setQuantity(int q)            { this.quantity = q; }
}
