package com.example;

import com.example.ws.order.OrderRequest;
import com.example.ws.order.OrderResponse;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.Marshaller;
import org.junit.jupiter.api.Test;

import java.io.StringWriter;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Baseline smoke tests — all must PASS before starting any lab.
 * Run with:  mvn test -Dtest=SmokeTest
 * Do NOT modify these tests.
 *
 * Note on JAXB imports:
 *   These tests use jakarta.xml.bind.* because this module's JAX-WS runtime
 *   (com.sun.xml.ws:jaxws-rt) depends on jakarta.xml.ws-api:2.3.x, which in
 *   turn bundles jakarta.xml.bind.*. This is intentionally correct for the
 *   JAX-WS module and differs from the JAX-RS modules which use javax.xml.bind.*.
 */
class SmokeTest {

    // ── Domain models (pre-built JAXB beans) ─────────────────────────────

    @Test
    void orderRequest_canBeConstructed() {
        OrderRequest req = new OrderRequest("C001", "PROD-42", 3);
        assertEquals("C001",    req.getCustomerId());
        assertEquals("PROD-42", req.getProductId());
        assertEquals(3,         req.getQuantity());
    }

    @Test
    void orderResponse_canBeConstructed() {
        OrderResponse resp = new OrderResponse();
        resp.setOrderId("ORD-001");
        resp.setStatus("ACCEPTED");
        resp.setMessage("All good");
        assertEquals("ORD-001",  resp.getOrderId());
        assertEquals("ACCEPTED", resp.getStatus());
        assertEquals("All good", resp.getMessage());
    }

    // ── JAXB serialisation sanity ─────────────────────────────────────────

    @Test
    void orderRequest_jaxbContext_canBeCreated() throws Exception {
        // jakarta.xml.bind is correct here — provided by jaxws-rt on the classpath
        JAXBContext ctx = JAXBContext.newInstance(
            OrderRequest.class, OrderResponse.class);
        assertNotNull(ctx);
    }

    @Test
    void orderRequest_canBeMarshalledToXml() throws Exception {
        JAXBContext ctx = JAXBContext.newInstance(OrderRequest.class);
        Marshaller m = ctx.createMarshaller();
        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        StringWriter sw = new StringWriter();
        m.marshal(new OrderRequest("C001", "PROD-42", 3), sw);
        String xml = sw.toString();
        assertTrue(xml.contains("C001"),    "XML must contain customerId");
        assertTrue(xml.contains("PROD-42"), "XML must contain productId");
        assertTrue(xml.contains("3"),       "XML must contain quantity");
    }
}
